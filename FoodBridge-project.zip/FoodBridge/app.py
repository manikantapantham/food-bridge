import os
import sqlite3
import secrets
import string
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # For a public deployment, restrict origins to your frontend domain.

@app.get("/")
def frontend_home():
    return send_from_directory(".", "index.html")

@app.get("/<path:filename>")
def frontend_files(filename):
    if filename in ("index.html", "style.css", "script.js"):
        return send_from_directory(".", filename)
    return ("Not found", 404)


DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
DB_PATH = Path(os.environ.get("FOODBRIDGE_DB", "foodbridge.db"))


def get_connection():
    if DATABASE_URL:
        import psycopg
        from psycopg.rows import dict_row
        url = DATABASE_URL
        if url.startswith("postgres://"):
            url = url.replace("postgres://", "postgresql://", 1)
        return psycopg.connect(url, row_factory=dict_row)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_connection() as conn:
        if DATABASE_URL:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS listings (
                    id SERIAL PRIMARY KEY,
                    name TEXT NOT NULL,
                    routing TEXT NOT NULL CHECK (routing IN ('Human','Animal')),
                    category TEXT NOT NULL,
                    quantity DOUBLE PRECISION NOT NULL,
                    servings INTEGER NOT NULL DEFAULT 0,
                    hours DOUBLE PRECISION NOT NULL DEFAULT 2,
                    location TEXT NOT NULL,
                    donor TEXT NOT NULL,
                    pickup TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    claimed BOOLEAN NOT NULL DEFAULT FALSE,
                    pickup_code TEXT DEFAULT ''
                )
            """)
        else:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS listings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    routing TEXT NOT NULL CHECK (routing IN ('Human','Animal')),
                    category TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    servings INTEGER NOT NULL DEFAULT 0,
                    hours REAL NOT NULL DEFAULT 2,
                    location TEXT NOT NULL,
                    donor TEXT NOT NULL,
                    pickup TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    claimed INTEGER NOT NULL DEFAULT 0,
                    pickup_code TEXT DEFAULT ''
                )
            """)
        conn.commit()


def row_to_dict(row):
    item = dict(row)
    item["claimed"] = bool(item.get("claimed"))
    item["quantity"] = float(item["quantity"])
    item["hours"] = float(item["hours"])
    item["servings"] = int(item.get("servings") or 0)
    return item


def calculate_stats(rows):
    total_kg = sum(float(r["quantity"]) for r in rows)
    human_kg = sum(float(r["quantity"]) for r in rows if r["routing"] == "Human")
    animal_kg = sum(float(r["quantity"]) for r in rows if r["routing"] == "Animal")
    meals = sum(int(r.get("servings") or 0) for r in rows if r["routing"] == "Human")
    available = sum(1 for r in rows if not r["claimed"])
    claims = sum(1 for r in rows if r["claimed"])
    categories = {}
    for r in rows:
        categories[r["category"]] = categories.get(r["category"], 0) + float(r["quantity"])
    return {
        "total_kg": round(total_kg, 1), "human_kg": round(human_kg, 1),
        "animal_kg": round(animal_kg, 1), "meals": meals, "available": available,
        "claims": claims, "categories": {k: round(v, 1) for k, v in categories.items()}
    }


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "database": "postgresql" if DATABASE_URL else "sqlite"})


@app.get("/api/listings")
def get_listings():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM listings ORDER BY id DESC").fetchall()
    items = [row_to_dict(r) for r in rows]
    return jsonify({"listings": items, "stats": calculate_stats(items)})


@app.post("/api/listings")
def create_listing():
    data = request.get_json(silent=True) or {}
    required = ["name", "routing", "category", "quantity", "location", "donor"]
    missing = [key for key in required if data.get(key) is None or str(data.get(key)).strip() == ""]
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400
    try:
        quantity = float(data["quantity"])
        servings = int(data.get("servings") or 0)
        hours = float(data.get("hours") or 2)
    except (TypeError, ValueError):
        return jsonify({"error": "Quantity, servings and pickup window must be valid numbers."}), 400
    if quantity <= 0 or quantity > 10000 or servings < 0 or hours <= 0:
        return jsonify({"error": "Enter a valid quantity, serving count and pickup window."}), 400
    if data["routing"] not in ("Human", "Animal"):
        return jsonify({"error": "Routing must be Human or Animal."}), 400

    values = (
        str(data["name"]).strip()[:70], data["routing"], str(data["category"])[:70],
        quantity, servings, hours, str(data["location"]).strip()[:150],
        str(data["donor"]).strip()[:70], str(data.get("pickup", ""))[:10],
        str(data.get("notes", ""))[:250], datetime.now(timezone.utc).isoformat()
    )
    with get_connection() as conn:
        if DATABASE_URL:
            row = conn.execute("""
                INSERT INTO listings (name,routing,category,quantity,servings,hours,location,donor,pickup,notes,created_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *
            """, values).fetchone()
        else:
            cur = conn.execute("""
                INSERT INTO listings (name,routing,category,quantity,servings,hours,location,donor,pickup,notes,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, values)
            row = conn.execute("SELECT * FROM listings WHERE id=?", (cur.lastrowid,)).fetchone()
        conn.commit()
    return jsonify({"listing": row_to_dict(row)}), 201


@app.post("/api/listings/<int:listing_id>/claim")
def claim_listing(listing_id):
    alphabet = string.ascii_uppercase + string.digits
    code = "FB-" + "".join(secrets.choice(alphabet) for _ in range(6))
    with get_connection() as conn:
        if DATABASE_URL:
            row = conn.execute("SELECT * FROM listings WHERE id=%s", (listing_id,)).fetchone()
        else:
            row = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
        if row is None:
            return jsonify({"error": "Listing not found."}), 404
        if row["claimed"]:
            return jsonify({"error": "This listing has already been claimed."}), 409
        if DATABASE_URL:
            updated = conn.execute(
                "UPDATE listings SET claimed=TRUE, pickup_code=%s WHERE id=%s AND claimed=FALSE RETURNING *",
                (code, listing_id)
            ).fetchone()
        else:
            cur = conn.execute(
                "UPDATE listings SET claimed=1, pickup_code=? WHERE id=? AND claimed=0",
                (code, listing_id)
            )
            updated = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
            if cur.rowcount == 0:
                return jsonify({"error": "This listing has already been claimed."}), 409
        conn.commit()
    return jsonify({"listing": row_to_dict(updated), "pickup_code": code})


@app.get("/api/stats")
def stats():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM listings").fetchall()
    return jsonify(calculate_stats([row_to_dict(r) for r in rows]))


@app.errorhandler(500)
def server_error(_error):
    return jsonify({"error": "Internal server error. Check the Flask server logs."}), 500


init_db()

if __name__ == "__main__":
    # Debug is for local development only. Do not enable debug on a public server.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=True)
