# FoodBridge prototype

## Run locally (Windows / VS Code)

1. Install Python 3.10+.
2. Open the `FoodBridge` folder in VS Code.
3. Open Terminal in VS Code and run:

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

4. Run `python app.py`.
5. Open `http://127.0.0.1:5000`. Flask serves the frontend and API from the same origin, so leave `API_BASE = ""` in `script.js`.

## Deploy

- Frontend: Vercel can host the static HTML/CSS/JS.
- Backend: deploy `app.py` to a Python host such as Render. Build command: `pip install -r requirements.txt`; start command: `gunicorn app:app`.
- Database: configure a managed PostgreSQL database and set the backend environment variable `DATABASE_URL` to its connection string. Do not commit secrets to GitHub.
- After deploying the backend, set `API_BASE` in `script.js` to the backend URL, e.g. `https://your-backend.onrender.com`, and redeploy the frontend.
- Configure CORS to allow only your actual frontend domain before public use.

## Prototype limitations

This is a hackathon demo, not a production food-safety or identity-verification system. Pickup codes are demo references, not secure authentication. Add login, authorization, rate limiting, expiry rules, and real pickup verification before real-world use.
