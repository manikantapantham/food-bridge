/*
  For local development, leave API_BASE empty: requests go to Flask at /api
  when served by Flask. If hosting the static frontend separately, set API_BASE
  to your deployed backend URL, e.g. "https://your-app.onrender.com".
*/
const API_BASE = ""; // Example: "https://your-flask-backend.onrender.com"
const API = `${API_BASE}/api`;
let listings = [];
let currentFilter = "all";
let pieChartInstance = null;
let barChartInstance = null;
const $ = id => document.getElementById(id);

$("year").textContent = new Date().getFullYear();

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
}
function switchPage(page) {
  document.querySelectorAll(".page-view").forEach(el => el.classList.toggle("active", el.id === `page-${page}`));
  document.querySelectorAll(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.page === page));
  window.scrollTo({top: 0, behavior: "smooth"});
  if (page === "dashboard") loadStats();
}
document.querySelectorAll("[data-page]").forEach(el => el.addEventListener("click", e => {
  e.preventDefault(); switchPage(el.dataset.page);
}));
document.querySelectorAll("[data-go]").forEach(el => el.addEventListener("click", () => switchPage(el.dataset.go)));

function openModal() { $("donateModal").classList.add("open"); }
function closeModal() { $("donateModal").classList.remove("open"); }
["openDonate","openDonateHero"].forEach(id => $(id).addEventListener("click", openModal));
["closeModal","cancelModal"].forEach(id => $(id).addEventListener("click", closeModal));
$("donateModal").addEventListener("click", e => { if (e.target === $("donateModal")) closeModal(); });

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {"Content-Type":"application/json", ...(options.headers || {})}
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function setConnection(ok, message) {
  const el = $("connectionStatus");
  if (!el) return;
  el.textContent = message;
  el.classList.toggle("error", !ok);
}
function safe(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function foodEmoji(item) {
  if (item.routing === "Animal") return "🥬";
  const s = `${item.category} ${item.name}`.toLowerCase();
  if (s.includes("bakery") || s.includes("bread")) return "🥐";
  if (s.includes("fruit") || s.includes("vegetable") || s.includes("produce")) return "🥗";
  return "🍱";
}
function renderListings() {
  const q = $("searchInput").value.trim().toLowerCase();
  const filtered = listings.filter(item => {
    const routeOK = currentFilter === "all" || item.routing === currentFilter;
    const queryOK = `${item.name} ${item.location} ${item.donor} ${item.category}`.toLowerCase().includes(q);
    return routeOK && queryOK;
  });
  const grid = $("foodGrid");
  if (!filtered.length) {
    grid.innerHTML = '<div class="empty">No matching food listings. Try another search or add a donation.</div>';
    return;
  }
  grid.innerHTML = filtered.map(item => `
    <article class="food-card">
      <div class="food-photo">${foodEmoji(item)}<span class="route-badge ${item.routing === "Animal" ? "animal" : ""}">${item.routing === "Human" ? "🥗 Human food" : "🐄 Farm scraps"}</span></div>
      <div class="card-body">
        <div class="card-title"><div><h3>${safe(item.name)}</h3><p>By ${safe(item.donor)}</p></div><span class="servings">${Number(item.quantity).toLocaleString()} kg</span></div>
        <div class="card-meta"><span>📍 ${safe(item.location)}</span><span>🏷️ ${safe(item.category)}</span><span>🍽️ ${Number(item.servings || 0)} servings</span></div>
        <p class="card-meta">${safe(item.notes || "No extra notes provided.")}</p>
        <div class="card-bottom"><small>${item.claimed ? "Already claimed" : `Pickup window: ${Number(item.hours)} hour(s)`}</small>
        <button class="btn ${item.claimed ? "btn-outline" : "btn-primary"} claim-btn" data-claim="${item.id}" ${item.claimed ? "disabled" : ""}>${item.claimed ? "Claimed" : "Claim food"}</button></div>
      </div>
    </article>`).join("");
  grid.querySelectorAll("[data-claim]").forEach(btn => btn.addEventListener("click", () => claimFood(btn.dataset.claim)));
}
async function loadListings() {
  try {
    const data = await request("/listings");
    listings = data.listings || [];
    setConnection(true, "● Connected to the FoodBridge backend");
    renderListings();
    updateHomeStats(data.stats);
  } catch (err) {
    listings = [];
    setConnection(false, `● Backend not connected: ${err.message}. Start the Flask server and refresh.`);
    renderListings();
  }
}
function updateHomeStats(stats = {}) {
  $("statMeals").textContent = Number(stats.meals || 0).toLocaleString();
  $("statKg").textContent = `${Number(stats.total_kg || 0).toFixed(1)} kg`;
  $("statListings").textContent = Number(stats.available || 0).toLocaleString();
  $("statClaims").textContent = Number(stats.claims || 0).toLocaleString();
}
async function claimFood(id) {
  try {
    const result = await request(`/listings/${encodeURIComponent(id)}/claim`, {method:"POST", body:JSON.stringify({})});
    toast(`Claim recorded! Pickup reference: ${result.pickup_code}`);
    await loadListings();
    await loadStats();
  } catch (err) { toast(err.message); }
}
$("donateForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form = new FormData(e.currentTarget);
  const payload = Object.fromEntries(form.entries());
  payload.quantity = Number(payload.quantity);
  payload.servings = Number(payload.servings || 0);
  payload.hours = Number(payload.hours || 2);
  try {
    const result = await request("/listings", {method:"POST", body:JSON.stringify(payload)});
    closeModal();
    e.currentTarget.reset();
    toast(`Donation published! Listing #${result.listing.id}`);
    await loadListings();
    await loadStats();
    switchPage("listings");
  } catch (err) { toast(`Could not publish: ${err.message}`); }
});
document.querySelectorAll(".filter-btn").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".filter-btn").forEach(b => b.classList.toggle("active", b === btn));
  currentFilter = btn.dataset.filter;
  renderListings();
}));
$("searchInput").addEventListener("input", renderListings);
$("clearSearch").addEventListener("click", () => { $("searchInput").value = ""; currentFilter = "all"; document.querySelectorAll(".filter-btn").forEach(b => b.classList.toggle("active", b.dataset.filter === "all")); renderListings(); });

async function loadStats() {
  try {
    const stats = await request("/stats");
    $("dashMeals").textContent = Number(stats.meals || 0).toLocaleString();
    $("dashKg").textContent = `${Number(stats.total_kg || 0).toFixed(1)} kg`;
    $("dashHuman").textContent = `${Number(stats.human_kg || 0).toFixed(1)} kg`;
    $("dashAnimal").textContent = `${Number(stats.animal_kg || 0).toFixed(1)} kg`;
    updateHomeStats(stats);
    if (!window.Chart) return;
    if (pieChartInstance) pieChartInstance.destroy();
    if (barChartInstance) barChartInstance.destroy();
    pieChartInstance = new Chart($("pieChart"), {
      type:"doughnut",
      data:{labels:["Human food","Farm scraps"],datasets:[{data:[stats.human_kg || 0,stats.animal_kg || 0],backgroundColor:["#176b4d","#c7f36b"],borderWidth:0}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom"}}}
    });
    const labels = Object.keys(stats.categories || {});
    const values = Object.values(stats.categories || {});
    barChartInstance = new Chart($("barChart"), {
      type:"bar",
      data:{labels,datasets:[{label:"Quantity (kg)",data:values,backgroundColor:"#176b4d",borderRadius:7}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}
    });
  } catch (err) { toast(`Could not load dashboard: ${err.message}`); }
}
$("refreshStats").addEventListener("click", loadStats);
loadListings();
